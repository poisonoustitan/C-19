var path,pathImage;
var boy,boyImage;
var vaccine,vaccineImage;
var virus,virusImage;
var restart,restartImage;

var END =0;
var PLAY =1;
var gameState = PLAY;

var immunity=0;

function preload(){
  pathImage = loadImage("background.jpg");
  boyImage = loadImage("delivery boy.png");
  vaccineImage = loadImage("vaccine.png");
  virusImage = loadImage("virus cartoon.jpg");
  restartImage = loadImage("restart.jpg");
  
}

function setup(){
  
createCanvas(400,400);
// Moving background
path=createSprite(400,400);
path.addImage(pathImage);
path.velocityX = 4;

//creating boy running
boy  = createSprite(30,300,20,20);
boy.addImage("Boyride",boyImage);
boy.scale=0.2;
boy.velocityX=2;
  
  
restart = createSprite(200,150);
restart.addImage(restartImage);
restart.scale = 0.8;
restart.visible = false;  

vaccine = createSprite(40,280,20,30);
vaccine.addImage(vaccineImage);
vaccine.scale = 0.05;
vaccine.velocityX=-2;
  
virus = createSprite(20,280,20,30);
virus.addImage(virusImage);
virus.scale = 0.05;
virus.velocityX=-2;
  
}

function draw() {
  background(0);
  
  drawSprites();
  textSize(20);
  fill(255);
  text("Immunity: "+ immunity,30,50);
  
  if(gameState===PLAY){
    
  var spawn=Math.random(1,6)
    if(spawn%2===0){
      spawnVirus();
    }
    else{
      spawnVaccine();
    }
    
   immunity = immunity + Math.round(getFrameRate()/50);
   path.velocityX = -(6 + 2*immunity/150);
  
   boy.Y = World.mouseY;
  
   edges= createEdgeSprites();
   boy .collide(edges);
  
  //code to reset the background
  if(path.x < 0 ){
    path.x = path.width/2;
    
    if(boy.isTouching(vaccine)){
      immunity=immunity+30;
    }
    
    if(boy.isTouching(virus)){
      gameState=END;
    }
  }
  }
  else if (gameState === END) {
  restart.visible = true;
  
    path.velocityX = 0;
    boy.velocityY = 0;
  
    
    //write condition for calling reset( )
  if(mousePressedOver(gameOver)){
    reset();
  }
}
}



function reset(){
  immunity=0;
  
  boy.addAnimation("boyride",boyImage);
  restart.visible=false;
  gameState=PLAY;
}

 function spawnVirus(){
       virus =createSprite(1100,Math.round(random(50, 250)));
        virus.scale =0.06;
        virus.velocityX = -(6 + 2*path/150);
        virus.setLifetime=170;
 }

function spawnVaccine(){
        vaccine=createSprite(1100,Math.round(random(50,250)));
  vaccine.scale=0.06;
  vaccine.velocityX=-(6+2*path/150);
  vaccine.setLifetime=170;

}